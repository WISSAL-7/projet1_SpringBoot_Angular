package modeles;

public enum Role {
    ADMIN,
    MEDECIN,
    PATIENT
}

