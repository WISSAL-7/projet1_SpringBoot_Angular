package modeles;

public enum StatutRendezVous {
    PLANIFIE, CONFIRME, ANNULE, TERMINE
}